package dao;

import java.util.HashMap;

import bean.BankBean;

public class BankDao implements BankDaoI {

	HashMap hashMap;
	BankBean bean = new BankBean();

	public BankDao() {
		hashMap = new HashMap();
	}

	public BankBean checkAccount(long accNo) {
		if (hashMap.containsKey(accNo)) {
			bean = (BankBean) hashMap.get(accNo);
			return bean;
		} else
			return null;
	}

	public void setData(long accNo, BankBean bean) {
		hashMap.put(accNo, bean);
	}
	
	public HashMap getData() {
		return hashMap;
	}
}