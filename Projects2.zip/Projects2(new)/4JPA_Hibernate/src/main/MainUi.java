package main;

import java.util.Scanner;

import entity.BankDetails;
import entity.TransactionDetails;
import service.BankService;

/*
 * Options Menu
 */
public class MainUi {
	public static void Menu() {
		System.out.println("\n\n\n*************XYZ Wallet***************");
		System.out.println("_____________________________________________");
		System.out.println(
				"1. CreateAccount \n 2. Show Balance \n 3. Deposit \n 4. WithDraw \n 5. Fund Transfer \n 6. Print Transaction \n 7. Exit");
		System.out.println("______________________________________________\n");
	}

	public static void main(String[] args) throws InvalidException {
		do {
			Menu();
			Scanner scanner = new Scanner(System.in);
			BankService service = new BankService();
			BankDetails bank = new BankDetails();
			TransactionDetails transaction = new TransactionDetails();
			TransactionDetails trans1 = new TransactionDetails();
			int opt = scanner.nextInt();

			switch (opt) {

			/*
			 * Create Account
			 */
			case 1:
				System.out.println("Enter Account Name: ");
				String name = scanner.next();
				if (name == null || name.length() > 12) {
					throw new InvalidException("Enter valid Name");
				}
				System.out.print("Enter Mobile Number: ");
				String mobileNo = scanner.next();
				if (mobileNo.length() != 10) {
					throw new InvalidException("Enter valid Mobile Number");
				}
				bank.setAccId();
				bank.setAccountantName(name);
				bank.setMobileno(mobileNo);
				System.out.print("Enter Mobile Number: ");
				int balance = scanner.nextInt();
				if (balance < 0) {
					throw new InvalidException("Enter valid Balance");
				}
				bank.setAccBalance(balance);
				service.CreateAccount(bank);
				System.out.println("Created Successfully");
				int id = bank.getAccId();
				service.getAccountById(id);
				System.out.println("Your Account ID is: " + bank.getAccId());
				System.out.println("______________________________________________________________");
				break;

			/*
			 * Show Balance
			 */
			case 2:
				System.out.print("Enter your account ID: ");
				int accountId = scanner.nextInt();
				if (accountId == 0) {
					throw new InvalidException("Enter valid Account ID");
				}
				bank = service.getAccountById(accountId);
				System.out.println("Accountant Name: " + bank.getAccountantName());
				System.out.println("Your Account Balance is: " + bank.getAccBalance());
				System.out.println("______________________________________________________________");
				break;

			/*
			 * Deposit
			 */
			case 3:
				System.out.print("Enter your Account ID: ");
				int depositId = scanner.nextInt();
				if (depositId == 0) {
					throw new InvalidException("Enter valid Account ID");
				}
				bank = service.getAccountById(depositId);
				System.out.println("Accountant Name: " + bank.getAccountantName());
				System.out.println("Your Account Balance is: " + bank.getAccBalance());
				int initBalance = bank.getAccBalance();
				System.out.print("Enter the Amount to Deposit: ");
				int depositAmt = scanner.nextInt();
				int finalBalance = initBalance + depositAmt;
				bank.setAccBalance(finalBalance);
				service.Deposit(bank);
				transaction.setTransactionType("Deposit");
				transaction.setAccId(depositId);
				transaction.setAmount(depositAmt);
				service.addTransaction(transaction);
				bank.setT(transaction);
				bank = service.getAccountById(depositId);
				System.out.println("Hello  " + bank.getAccountantName());
				System.out.println(
						"Your Account Balance after Depositing " + depositAmt + " Rs is " + bank.getAccBalance());
				System.out.println("\n__________________________________________________________\n");
				break;

			/*
			 * Withdraw
			 */
			case 4:
				System.out.print("Enter your account ID: ");
				int withdrawId = scanner.nextInt();
				if (withdrawId == 0) {
					throw new InvalidException("Enter valid Account ID");
				}
				bank = service.getAccountById(withdrawId);
				System.out.println("Hello " + bank.getAccountantName());
				System.out.println(" Your Account Balance is: " + bank.getAccBalance());
				int initBal = bank.getAccBalance(); // initial balance
				System.out.println("____________________________________________");
				System.out.print("Enter the Amount to Withdraw: ");
				int withdrawAmt = scanner.nextInt();
				int finalBal = initBal - withdrawAmt;
				bank.setAccBalance(finalBal);
				service.Withdraw(bank);
				transaction.setTransactionType("Withdraw");
				transaction.setAccId(withdrawId);
				transaction.setAmount(withdrawAmt);
				service.addTransaction(transaction);
				bank.setT(transaction);
				bank = service.getAccountById(withdrawId);
				System.out.println("Hello " + bank.getAccountantName());
				System.out.println("Your Remaining Account Balance after Withdraw " + withdrawAmt + " Rs is"
						+ bank.getAccBalance());
				System.out.println("\n____________________________________________________________\n");
				break;

			/*
			 * Funds Transfer
			 */
			case 5:
				System.out.print("Enter Source Account ID: ");
				int fid = scanner.nextInt(); // From Account Id (Sender)
				if (fid == 0) {
					throw new InvalidException("Enter valid Account ID");
				}
				bank = service.getAccountById(fid);
				int bal = bank.getAccBalance(); // Initial Balance
				System.out.print("Enter the amount to transfer: ");
				int fund = scanner.nextInt(); // Amount to be transfered
				System.out.print("Enter Reciever Account ID: ");

				int tid = scanner.nextInt();
				if (tid == 0) {
					throw new InvalidException("Enter valid Account ID");
				}

				// Removing the Balance transfered from sender Account
				bank = service.getAccountById(fid);
				int bal1 = bal - fund;
				bank.setAccBalance(bal1);
				service.Deposit(bank);

				// updating the Balance recieved from Sender
				bank = service.getAccountById(tid);
				int tbal = bank.getAccBalance();
				int tbalance = tbal + fund;
				bank.setAccBalance(tbalance);
				service.Deposit(bank);

				// updating In transaction Table
				transaction.setTransactionType("Transfered to " + tid);
				transaction.setAccId(fid);
				transaction.setAmount(fund);
				service.addTransaction(transaction);
				bank.setT(transaction);
				int a = transaction.getTransactionId();
				bank = service.getAccountById(fid);
				System.out.println("Hello " + bank.getAccountantName());
				System.out.println("Remaining balance in account " + bank.getAccBalance());
				System.out.println("\n________________________________________________________\n");
				break;

			/*
			 * Print Transactions
			 */
			case 6:
				System.out.print("Enter the account ID: ");
				int trid = scanner.nextInt();
				service.PrintTransactions(trid);
				System.out.println("\n\n__________________________________________________________");
				break;

			/*
			 * Exit
			 */
			case 7:
				System.out.println("Thanks for using our Bank Services !");
				System.exit(0);
			}
		} while (true);
	}
}