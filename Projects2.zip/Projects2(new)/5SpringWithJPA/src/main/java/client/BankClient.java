package client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cap.entities.Transaction;

import service.BankService;

public class BankClient {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		BankService bankService = context.getBean("bankService", BankService.class);
		String press1;
		int c, balance;
		String choice, name, password, phoneNo;

		while (true) {
			/*
			 * Menu
			 */
			System.out.println("**************XYZ wallet*********************");
			System.out.println("\t 1. Create account");
			System.out.println("\t 2. Show balance");
			System.out.println("\t 3. Deposit");
			System.out.println("\t 4. Withdraw money");
			System.out.println("\t 5. Funds transfer");
			System.out.println("\t 6. Print transactions");
			System.out.println("\t 7. Exit");
			System.out.println("*********************************************");

			System.out.print("Enter Your choice: ");
			press1 = scanner.next();

			if (press1.matches("[a-z]*") || press1.matches("[A-Z]*")) {
				System.out.println("Invalid Choice!!!");
				main(null);
			}

			switch (press1) {

			/*
			 * Create Account
			 */
			case "1":
				do {
					System.out.print("Enter your name: ");
					name = scanner.next();
					c = bankService.nameValidate(name);
				} while (c != 1);

				do {
					System.out.print("Enter your phone number: ");
					phoneNo = scanner.next();
					c = bankService.mobNoValidate(phoneNo);
				} while (c != 1);

				long phone1 = Long.parseLong(phoneNo);
				long accountNo = phone1 + 1;

				do {
					System.out.print("Create password: ");
					password = scanner.next();
					c = bankService.passwordValidate(password);
				} while (c != 1);

				do {
					System.out.println("Enter balance: ");
					balance = scanner.nextInt();
					c = bankService.checkBalance(balance);
				} while (c != 1);

				boolean result = bankService.createAccount(name, phoneNo, password, accountNo, balance);
				if (result) {
					System.out.println("Account created successful");
				}
				break;

			/*
			 * Show Balance
			 */
			case "2":
				System.out.println("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.println("Enter your password: ");
				password = scanner.next();
				boolean b1 = bankService.validateAccount(accountNo, password);
				if (b1) {
					balance = bankService.showBalance(accountNo);
					if (balance != 0) {
						System.out.println("Your account balance is: " + balance);
					} else {
						System.out.println("Problem ");
					}
				} else {
					System.out.println("Wrong credentials");
				}
				break;

			/*
			 * Deposit
			 */
			case "3":
				System.out.print("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.print("Enter your password: ");
				password = scanner.next();
				boolean b = bankService.validateAccount(accountNo, password);
				if (b) {
					System.out.print("Enter the amount to be deposited: ");
					int deposit = scanner.nextInt();
					balance = bankService.depositAmount(accountNo, deposit);
					System.out.println("Amount deposited");
					System.out.println("your new balance is " + balance);
				} else {
					System.out.println("Wrong credentials");
				}
				break;

			/*
			 * Withdraw
			 */
			case "4":
				System.out.print("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.print("Enter your password: ");
				password = scanner.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					balance = bankService.showBalance(accountNo);
					System.out.println("Your current balance is " + balance);
					System.out.print("Enter the amount to be withdrawal: ");
					int withdraw = scanner.nextInt();
					balance = bankService.withdrawAmount(accountNo, withdraw);
					if (balance >= 0) {
						System.out.println("Amount withdrawal");
						System.out.println("You debited " + withdraw);
						System.out.println("your new balance is " + balance + "\n");
					} else {
						System.out.println("Insufficient funds");
					}
				} else {
					System.out.println("wrong credential");
				}
				break;

			/*
			 * Funds Transfer
			 */
			case "5":
				System.out.print("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.print("Enter your password: ");
				password = scanner.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					System.out.print("Enter account no to transfer: ");
					long accno = scanner.nextLong();
					System.out.print("Enter the amount to transfer: ");
					int amount = scanner.nextInt();
					boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
					if (transfer) {
						System.out.println(amount + " is transferred successfully\n");
					} else {
						System.out.println("Transfer Failed");
					}
				} else {
					System.out.println("Invalid Account");
				}
				break;

			/*
			 * Print Transactions
			 */
			case "6":
				System.out.print("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.print("Enter your password: ");
				password = scanner.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					List<Transaction> trans = bankService.getTransaction(accountNo);
					System.out.println("***********Account Statement***********\n");
					for (Transaction tran : trans) {
						System.out.println(tran);
					}
				} else {
					System.out.println("Account not exist!");
				}
				break;

			/*
			 * Exit
			 */
			case "7":
				System.out.println("Thanks for using XYZ Wallet");
				System.exit(0);
			}
		}
	}
}